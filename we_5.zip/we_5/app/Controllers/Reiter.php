<?php

namespace App\Controllers;

class Reiter extends BaseController
{

    public function index(){
        $data['titel'] = "Aufgabenplaner: Reiter";
        echo view('templates/header', $data);
        echo view('reiter');
    }

}