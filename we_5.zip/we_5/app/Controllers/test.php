<?php

namespace App\Controllers;

class test extends BaseController
{
    public function index(){
        if(isset($_POST['usernane']) && isset($_POST['passwort'])){
            echo view('templates/header');
        }
    }
}