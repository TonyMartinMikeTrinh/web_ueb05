<?php

namespace App\Controllers;

class Projekte extends BaseController
{
    public function index(){ //projekte
        $data['titel'] = "Aufgabenplaner: Projekte";
        echo view('templates/header', $data);
        echo view('projekte');
    }

}