<?php

namespace App\Controllers;

class Personen extends BaseController
{
    public function index(){ //personen
        $data['titel'] = "Aufgabenplaner: Personen";

        $data['mitglieder'] = array(
            array(  'id'=>1,
                'Name'=>'Max Mustermann',
                'Mail'=>'mustermann@muster.de',
                'In Projekt'=>'false'
            ),
            array(  'id'=>2,
                'Name'=>'Petra Müller',
                'Mail'=>'petra@mueller.de',
                'In Projekt'=>'false'
            )
        );

        $data['Reiter']= array(
            array('Aufgabenbezeichnung'=>'HTML Datei erstellen',
                'Beschreibung der Aufgabe'=>'HTML Datei erstellen',
                'Zuständig'=>$data['mitglieder'][0],
                'Reiter'=>"ToDo"
            ),
            array(  'Aufgabenbezeichnung'=>'CSS Datei erstellen',
                'Beschreibung der Aufgabe'=>'HTML Datei erstellen',
                'Zuständig'=>$data['mitglieder'][0],
                'Reiter'=>"ToDo"
            ),
            array(  'Aufgabenbezeichnung'=>'PC eingeschalet',
                'Beschreibung der Aufgabe'=>'PC einschalten',
                'Zuständig'=>$data['mitglieder'][0],
                'Reiter'=>"Erledigt"
            ),
            array(  'Aufgabenbezeichnung'=>'Kaffee trinken',
                'Beschreibung der Aufgabe'=>'Kaffee trinken',
                'Zuständig'=>$data['mitglieder'][1],
                'Reiter'=>"Erledigt"
            ),
            array(  'Aufgabenbezeichnung'=>'Für die Uni lernen',
                'Beschreibung der Aufgabe'=>'Für die Uni lernen.',
                'Zuständig'=>$data['mitglieder'][0],
                'Reiter'=>"Verschoben"
            )
        );

        echo view('templates/header', $data);
        echo view('personen');
    }
}