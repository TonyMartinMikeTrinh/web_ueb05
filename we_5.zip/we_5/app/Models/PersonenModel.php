<?php

use CodeIgniter\Model;

class PersonenModel extends Model
{

    public function getPersonen($person_id = NULL){

    }

    public function getAufgaben(){

    }

}