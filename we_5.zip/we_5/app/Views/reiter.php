<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://unpkg.com/bootstrap@5.2.2/dist/css/bootstrap.min.css"
          rel="stylesheet" />
    <title>Reiter</title>
</head>
<body>

<div class="row">

    <div class="col-2">
        <?php include "menu.php"?>
    </div>

    <div class="col-8" style="min-width: max-content">

        <div class="container-fluid">

            <table class="table">
                <thead class="thead-light">
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Beschreibung</th>
                    <th scope="col" style="align-items: end"></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>ToDo</td>
                    <td>Dinge die erledigt werden müssen.</td>
                    <td>
                        <img src="img/trash96.png" alt="change" class="rounded float-right ms-3" width="25vw" align="right">
                        <img src="img/write96.png" alt="change" class="rounded float-right" width="25vw" align="right">
                    </td>

                </tr>
                <tr>
                    <td>Erledigt</td>
                    <td>Dinge die erledigt sind.</td>
                    <td>
                        <img src="img/trash96.png" alt="change" class="rounded float-right ms-3" width="25vw" align="right">
                        <img src="img/write96.png" alt="change" class="rounded float-right" width="25vw" align="right">
                    </td>

                </tr>
                <tr>
                    <td>Verschoben</td>
                    <td>Dinge die später erledigt werden.</td>
                    <td>
                        <img src="img/trash96.png" alt="change" class="rounded float-right ms-3" width="25vw" align="right">
                        <img src="img/write96.png" alt="change" class="rounded float-right" width="25vw" align="right">
                    </td>

                </tr>
                </tbody>
            </table>

        </div>

    </div>

</div>

</body>
</html>