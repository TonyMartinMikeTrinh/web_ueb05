<?php

namespace App\Controllers;

class Login extends BaseController
{

    public function index()
    {
        $data['titel'] = "Aufgabenplaner: Login";
        echo view('templates/header', $data);
        echo view('login');
    }


    public function aktuellesProjekt(){
        echo view('login');
        echo "test";
    }

}